from moviepy.editor import *
from moviepy.audio.fx import all as afx
from PIL import Image

Image.ANTIALIAS = Image.Resampling.LANCZOS

WIDTH = 1080
HEIGHT = 1920

FONT_REGULAR = "/data/data/com.termux/files/usr/share/fonts/TTF/DejaVuSans.ttf"
FONT_BOLD = "/data/data/com.termux/files/usr/share/fonts/TTF/DejaVuSans-Bold.ttf"


def generate_video(title, description, audio_path):

    voice = AudioFileClip(audio_path)
    duration = voice.duration

    # Background
    bg = (
        VideoFileClip("assets/bg.mp4")
        .resize((WIDTH, HEIGHT))
        .subclip(0, duration)
    )

    overlay = (
        ColorClip((WIDTH, HEIGHT), color=(0, 0, 0))
        .set_opacity(0.5)
        .set_duration(duration)
    )

    # Anchor
    anchor = (
        ImageClip("static/anchor.png")
        .resize(height=750)
        .set_position((40, "center"))
        .set_duration(duration)
    )

    # Logo
    logo = (
        ImageClip("static/logo.jpg")
        .resize(height=100)
        .set_position(("center", 40))
        .set_duration(duration)
    )

    # TEXT AREA
    text_x = 420
    text_start_y = 420
    text_width = 620

    # Title
    title_clip = TextClip(
        title,
        fontsize=65,
        color="white",
        font=FONT_BOLD,
        method="caption",
        size=(text_width, None),
    ).set_duration(duration)

    title_clip = title_clip.set_position((text_x, text_start_y))

    # Description (dynamic positioning)
    desc_clip = TextClip(
        description,
        fontsize=45,
        color="white",
        font=FONT_REGULAR,
        method="caption",
        size=(text_width, None),
    ).set_duration(duration)

    desc_clip = desc_clip.set_position(
        (text_x, text_start_y + title_clip.h + 40)
    )

    # Breaking bar
    breaking_bar_y = HEIGHT - 220

    breaking_bar = (
        ColorClip((WIDTH, 130), color=(200, 0, 0))
        .set_position(("center", breaking_bar_y))
        .set_duration(duration)
    )

    breaking_text = (
        TextClip(
            "BREAKING NEWS",
            fontsize=55,
            color="white",
            font=FONT_BOLD,
            method="caption",
        )
        .set_position(("center", breaking_bar_y + 25))
        .set_duration(duration)
    )

    # AI label
    ai_label = (
        TextClip(
            "AI Generated Anchor",
            fontsize=28,
            color="white",
            font=FONT_REGULAR,
            method="caption",
        )
        .set_position((20, HEIGHT - 60))
        .set_duration(duration)
    )

    # Background music (loop safe)
    music_clip = AudioFileClip("assets/music.mp3")

    if music_clip.duration < duration:
        music = afx.audio_loop(music_clip, duration=duration)
    else:
        music = music_clip.subclip(0, duration)

    music = music.volumex(0.08)

    final_audio = CompositeAudioClip([music, voice])

    main_video = CompositeVideoClip(
        [
            bg,
            overlay,
            anchor,
            logo,
            title_clip,
            desc_clip,
            breaking_bar,
            breaking_text,
            ai_label,
        ]
    ).set_audio(final_audio)

    # Ending screen (3 sec)
    ending_duration = 3

    ending_bg = (
        ColorClip((WIDTH, HEIGHT), color=(0, 0, 0))
        .set_duration(ending_duration)
    )

    ending_text = (
        TextClip(
            "Presented by\nGrahak Chetna",
            fontsize=75,
            color="white",
            font=FONT_BOLD,
            method="caption",
            align="center",
        )
        .set_position("center")
        .set_duration(ending_duration)
    )

    ending_clip = CompositeVideoClip(
        [ending_bg, ending_text]
    ).set_duration(ending_duration)

    final = concatenate_videoclips([main_video, ending_clip])

    output_path = "static/final_video.mp4"

    final.write_videofile(
        output_path,
        fps=24,
        codec="libx264",
        audio_codec="aac",
    )

    return output_path
