import asyncio
import edge_tts
import re
import time

VOICE_MAP = {
    "english": "en-IN-PrabhatNeural",
    "hindi": "hi-IN-MadhurNeural",
    "gujarati": "gu-IN-NiranjanNeural",
}

OUTPUT_PATH = "output/voice.mp3"


def clean_text(text):
    # Remove unwanted special characters
    text = re.sub(r"[^\w\s.,!?-]", "", text)
    return text.strip()[:3000]


def format_news_script(text):
    # Professional news anchor format
    return f"""
Good evening.

Here is the latest update.

{text}.

Stay tuned for more updates.

Presented by Grahak Chetna.
"""


async def _generate(text, voice):
    communicate = edge_tts.Communicate(
        text=text,
        voice=voice,
        rate="-5%",        # Slightly slower (news style)
        pitch="+0Hz"
    )
    await communicate.save(OUTPUT_PATH)


def generate_voice(text, language="english"):

    voice = VOICE_MAP.get(language, "en-IN-PrabhatNeural")

    cleaned = clean_text(text)
    formatted_script = format_news_script(cleaned)

    for attempt in range(3):  # retry system
        try:
            asyncio.run(_generate(formatted_script, voice))
            return OUTPUT_PATH
        except Exception as e:
            print(f"Attempt {attempt + 1} failed:", e)
            time.sleep(1)

    return None
