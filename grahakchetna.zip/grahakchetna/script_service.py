import os
import requests
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("GROQ_API_KEY")

def generate_script(headline, description, language):

    if language == "gujarati":
        lang_instruction = "Write the script fully in Gujarati language."
    elif language == "hindi":
        lang_instruction = "Write the script fully in Hindi language."
    else:
        lang_instruction = "Write the script fully in English language."

    prompt = f"""
    Create a 45-second engaging YouTube Shorts news script.

    {lang_instruction}

    Headline: {headline}
    Description: {description}

    Make it energetic, clear, and suitable for short-form video.
    """

    url = "https://api.groq.com/openai/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": "llama-3.3-70b-versatile",
        "messages": [{"role": "user", "content": prompt}]
    }

    response = requests.post(url, headers=headers, json=data)

    if response.status_code != 200:
        print("Groq Error:", response.text)
        return None

    return response.json()["choices"][0]["message"]["content"]
